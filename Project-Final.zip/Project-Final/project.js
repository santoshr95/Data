function processData(data){

//Creating SVG
var svg = d3.select("#map").append("svg")
      .attr("height",700)
      .attr("width",1200)

    .style("background-color","skyblue")
    .call(d3.zoom().on("zoom", function () {
    svg.attr("transform", d3.event.transform)
 }))
 .append("g")
states=data[0]
first=data[1]
last=data[2]

//Using geoAlbersUsa projection 
var projection = d3.geoAlbersUsa()	
					.translate([350,100])
					.scale([2200])
				
var path = d3.geoPath()
			.projection(projection);

//Drawing the mao
svg.append("path")
    .datum(states)
    .attr("d", path)
    .style("stroke", "black")
    .style("stroke-opacity", "20%")
    .style("fill", "black");

//Putting the ships on map using circle as points
var circles = svg.selectAll(".first")
        .data(first.features)
        .join("circle")
        .attr("class", "first")
        .attr("id",d=>d.properties.VesselName)
        .attr("cx", function(d){
            pro=(projection(d.geometry.coordinates))
            // console.log(pro)
            if(pro==null)
            {
                return 999999;
            }
            else{
                return pro[0]
            }
            
        } )
        // => projection(d.geometry.coordinates)[0])
        .attr("cy", function(d){
           pro=(projection(d.geometry.coordinates))
            // console.log(pro)
            if(pro==null)
            {
                return 999999;
            }
            else{
                return pro[1]
            }
            
        } )
        .style("fill","red")
        .style("opacity",0.8)
        .attr("r", 2);

    //Showing the transition of ships from their start point to end point recorded on that dat
   	svg.selectAll("circle")
   		.data(last.features)
   		.transition()
   		.duration(40000)
   		.attr("cx",function(d){
   			name=this.id
   			if (name==d.properties.VesselName){
   				pro=(projection(d.geometry.coordinates))
            // console.log(pro)
            if(pro==null)
            {
                return 999999;
            }
            else{
                return pro[0]
            }
   			}
   		})
   		.attr("cy",function(d){
   			name=this.id
   			if (name==d.properties.VesselName){
   				pro=(projection(d.geometry.coordinates))
            // console.log(pro)
            if(pro==null)
            {
                return 999999;
            }
            else{
                return pro[1]
            }
   			}
   		})

    //Using zoom to pan over the map
    let zoom = d3.zoom()
   .scaleExtent([1, 20])
   .translateExtent([[-500, -300], [1500, 1000]])
   .on('zoom', () => {
       svg.attr('transform', d3.event.transform)
   });
 
types=first.features.map(function(d){
  return d.properties.VesselType
})

//Funcitonality for the select buttons 
type={"Cargo":[70,71,72,73,74,75,76,77,78,79],"Fishing":[30],"Military":[35]
,"Not Available":[0],"Other":[23,24,25,26,27,29,33,34,38,39,40,41,42,43,44,45,46,47,48,49,50,51,53,54,55,56,57,58,59,90,91,92,93,94,95,96,97,98,99],"Passenger":[60,61,62,63,64,65,66,67,68,69],"Pleasure Craft/Sailing Tanker":[36,37]
,"Tug Tow":[21,22,31,32,52]}
type1=["Select Vessel Type","Cargo","Fishing","Military","Not Available","Other","Passenger","Pleasure Craft/Sailing Tanker","Tug Tow"]
length={"Select vessel length":-1,"<50":0,"50-100":1,"100-150":2,"150-200":3,"200-250":4,"250-300":5,"300-350":6,"350-400":7}
lengths={0:[0,50],1:[50,100],2:[100,150],3:[150,200],4:[200,250],5:[250,300],6:[300,350],7:[350,400]}
console.log(lengths[0][1])
d3.select("#selectButton")
.selectAll("option")
.data(type1)
.enter()
.append('option')
.text((d,i)=>d)
.attr("value",d=>d)

d3.select("#selectButton2")
.selectAll("option")
.data(Object.keys(length))
.enter()
.append('option')
.text((d,i)=>d+" (Meters)")
.attr("value",d=>d)

}


d3.select("#selectButton").on("change", function(d) {
        var selection = d3.select(this).property("value")
        types=type[selection]
        d3.selectAll("#map circle")
          .classed("highlight","false")
          .attr("r",0)
          .style("fill","red")
          .style("opacity",0.8)

        d3.selectAll("#map circle").filter(dd=>types.includes(dd.properties.VesselType ))
        
        .classed("highlight","true")
        .attr("r",4)
        .style("fill","orange")
        .style("opacity",1)

        })


d3.select("#selectButton2").on("change", function(d) {
        var selection = d3.select(this).property("value")
        types=length[selection]
        console.log(types)
        d3.selectAll("#map circle")
          .classed("highlight","false")
          .attr("r",0)
          .style("fill","red")
          .style("opacity",0.8)



        d3.selectAll("#map circle").filter(function(dd){
          console.log(dd)
          if((dd.properties.Length>=lengths[types][0])&&(dd.properties.Length<=lengths[types][1]))
            // console.log(dd.property.Length)
            return dd
        })
        .classed("highlight","true")
        .attr("r",4)
        .style("fill","orange")
        .style("opacity",1)

        
    })

//Loading in the data 
Promise.all([d3.json("https://gist.githubusercontent.com/dakoop/f817ee9771707390504948a0ea22e89f/raw/83340d07d1fc36c9b85ce72a2e1a6894f2e28021/us-states.json"),
	d3.json("https://gist.githubusercontent.com/santoshr95/9ee9aaa47d317442db3b5e9a9c1d123e/raw/c6e5e662484ee72806b242199b5ea23cd590b208/first.json"),
	d3.json("https://gist.githubusercontent.com/santoshr95/9ee9aaa47d317442db3b5e9a9c1d123e/raw/c6e5e662484ee72806b242199b5ea23cd590b208/last.json")])
  .then(processData);







